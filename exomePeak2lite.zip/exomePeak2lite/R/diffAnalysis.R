#'@title Differential peak calling with MeRIP-Seq.
#'
#'@return the peaks in GRangesList format.
#'@export
diffAnalysis <- function(bam_IP,
                         bam_input,
                         bam_IP_treated,
                         bam_input_treated,
                         txdb = NULL,
                         genome = NULL,
                         bin_size = 25,
                         step_size = 25,
                         fragment_length = 100,
                         strandness = c("unstrand", "1st_strand", "2nd_strand"),
                         gff = NULL,
                         p_cutoff = 1e-3,
                         lfc_threshold = 0,
                         alt_hypothesis = c("greaterAbs", "lessAbs", "greater", "less"),
                         peak_calling_based = TRUE,
                         save_se = FALSE,
                         plot_gc = FALSE,
                         parallel = 1){
    require(GenomicRanges)
    require(GenomicFeatures)
    require(SummarizedExperiment)
    require(DESeq2)

    strandness <- match.arg(strandness)
    alt_hypothesis <- match.arg(alt_hypothesis)

    if(is.null(gff) & is.null(txdb)){
      stop("Please at least provide one among gff and TxDb for transcript annotation.")
    }

    if(is.null(txdb) & !is.null(gff)){
      txdb <- makeTxDbFromGFF(gff)
    }

    if(!(all(file.exists(bam_IP)) &
         all(file.exists(bam_input)) &
         all(file.exists(bam_IP_treated)) &
         all(file.exists(bam_input_treated)))){
      stop("At least one bam file directories provided cannot be found.")
    }

    #Extract bins for count
    exByGene  <- exonsByiGenes(txdb)
    peakBins <- exonicBins(exByGene, bin_size, step_size)
    mcols(peakBins) <- NULL

    #Count the bam files
    bam_dirs <- c(bam_IP, bam_IP_treated, bam_input, bam_input_treated)
    se <- featuresCounts(peakBins, bam_dirs, strandness, parallel)

    #Annotate SummarizedExperiment
    length_indx <- c(length(bam_IP), length(bam_IP_treated),
                     length(bam_input), length(bam_input_treated))
    se$IP_input <- rep(c("IP", "IP", "input", "input"), length_indx)
    se$Perturbation <- rep(c("C", "Treated", "C", "Treated"), length_indx)
    rm(peakBins, length_indx)

    #Identify Backgrounds
    se <- classifyBackground(se)

    #Estimate sample size factors
    se <- estimateColumnFactors(se)

    #Calculate GC contents
    se <- calculateGCcontents(se, fragment_length, exByGene, genome)

    #Fit GC content biases
    se <- fitBiasCurves(se)

    #Estimate matrix correction factors
    se <- estimateMatrixFactors(se)

    ## Plot GC bias fits
    if(plot_gc) plotGCbias(se)

    #Peak calling
    if(peak_calling_based){
    peaks <- callPeaks(se, 1e-10, exByGene, bin_size)

    #Count the bam files
    se2 <- featuresCounts(peaks, bam_dirs, strandness, parallel)
    rm(bam_dirs, peaks)

    #Re-annotate SummarizedExperiment
    colData(se2) <- colData(se)
    metadata(se2) <- metadata(se)
    rm(se)

    #Calculate GC contents
    se2 <- calculateGCcontents(se2, fragment_length, exByGene, genome)

    #Estimate matrix correction factors
    se2 <- estimateMatrixFactors(se2)

    #Export intermediate data for differential analysis
    if(save_se) saveRDS(se2, "se.rds")

    #Differential calling
    diffPeaks <- callDiff(se2, p_cutoff, exByGene, bin_size, alt_hypothesis, lfc_threshold)
    }else{
    if(save_se) saveRDS(se, "se.rds")
    diffPeaks <- callDiff(se, p_cutoff, exByGene, bin_size, alt_hypothesis, lfc_threshold)
    }

    return(diffPeaks)
}
