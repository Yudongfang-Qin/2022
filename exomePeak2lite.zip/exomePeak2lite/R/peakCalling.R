#'@title Peak calling with MeRIP-Seq.
#'
#'@return the peaks in GRangesList format.
#'@export
peakCalling <- function(bam_IP,
                        bam_input,
                        txdb = NULL,
                        genome = NULL,
                        bin_size = 25,
                        step_size = 25,
                        fragment_length = 100,
                        strandness = c("unstrand", "1st_strand", "2nd_strand"),
                        gff = NULL,
                        p_cutoff = 1e-10,
                        plot_gc = FALSE,
                        parallel = 1){
  require(GenomicRanges)
  require(SummarizedExperiment)
  require(DESeq2)

  #Check input validity
  strandness <- match.arg(strandness)

  if(is.null(gff) & is.null(txdb)){
    stop("Please at least provide one among gff and TxDb for transcript annotation.")
  }

  if(is.null(txdb) & !is.null(gff)){
    txdb <- makeTxDbFromGFF(gff)
  }

  if(!(all(file.exists(bam_IP)) & all(file.exists(bam_input)))){
    stop("At least one bam file directories provided cannot be found.")
  }

  #Extract bins for count
  exByGene  <- exonsByiGenes(txdb)
  peakBins <- exonicBins(exByGene, bin_size, step_size)
  mcols(peakBins) <- NULL

  #Count the bam files
  bam_dirs <- c(bam_IP, bam_input)
  se <- featuresCounts(peakBins, bam_dirs, strandness, parallel)
  rm(bam_dirs)

  #Annotate SummarizedExperiment
  se$IP_input <- rep(c("IP", "input"), c(length(bam_IP), length(bam_input)))
  rm(peakBins)

  #Identify Backgrounds
  se <- classifyBackground(se)

  #Estimate sample size factors
  se <- estimateColumnFactors(se)

  #Calculate GC contents
  se <- calculateGCcontents(se, fragment_length, exByGene, genome)

  #Fit GC content biases
  se <- fitBiasCurves(se)

  #Estimate matrix correction factors
  se <- estimateMatrixFactors(se)

  ## Plot GC bias fits
  if(plot_gc) plotGCbias(se)

  #DESeq2 peak calling
  peaks <- callPeaks(se, p_cutoff, exByGene, bin_size)

  return(peaks)
}
