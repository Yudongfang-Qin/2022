#Example
library(exomePeak2lite)
library(BSgenome.Hsapiens.UCSC.hg19)
library(TxDb.Hsapiens.UCSC.hg19.knownGene)

GENE_ANNO_GTF = system.file("extdata", "example.gtf", package="exomePeak2lite")
f1 = system.file("extdata", "IP1.bam", package="exomePeak2lite")
f2 = system.file("extdata", "IP2.bam", package="exomePeak2lite")
f3 = system.file("extdata", "IP3.bam", package="exomePeak2lite")
f4 = system.file("extdata", "IP4.bam", package="exomePeak2lite")
IP_BAM = c(f1,f2,f3,f4)
f1 = system.file("extdata", "Input1.bam", package="exomePeak2lite")
f2 = system.file("extdata", "Input2.bam", package="exomePeak2lite")
f3 = system.file("extdata", "Input3.bam", package="exomePeak2lite")
INPUT_BAM = c(f1,f2,f3)
f1 = system.file("extdata", "treated_IP1.bam", package="exomePeak2lite")
TREATED_IP_BAM = c(f1)
f1 = system.file("extdata", "treated_Input1.bam", package="exomePeak2lite")
TREATED_INPUT_BAM = c(f1)

#Differential analysis
diffAnalysis(bam_IP = IP_BAM,
             bam_input = INPUT_BAM,
             bam_IP_treated = TREATED_IP_BAM,
             bam_input_treated = TREATED_INPUT_BAM,
             gff = GENE_ANNO_GTF,
             genome = Hsapiens,
             plot_gc = TRUE,
             p_cutoff = c(1e-02,1e-010,1e-15,1e-20),
             save_se = TRUE) #P.S. Set paired_end = TRUE for paired-end library type

#Peak Calling
Peaks <- peakCalling(bam_IP = IP_BAM,
                     bam_input = INPUT_BAM,
                     txdb = TxDb.Hsapiens.UCSC.hg19.knownGene,
                     genome = Hsapiens,
                     plot_gc = TRUE,
                     p_cutoff = c(1e-05,1e-010,1e-15,1e-20)) #P.S. Set paired_end = TRUE for paired-end library type

#Plot transcript topology
#list_grl should be a list of GRanges / GRangesList
#names of the list will be the label
plotTopology(list_grl = Peaks, txdb = txdb, savePrefix = "topology")
